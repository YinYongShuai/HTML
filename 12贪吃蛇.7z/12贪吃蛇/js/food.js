(function(){
function Food(){
    this.width = 20;
    this.height = 20;
    this.x = 20;
    this.y = 20;
    this.color = "green";
    // 数组存储元素
    this.elements = [];
}
Food.prototype.render = function(map){
    this.x = tools.getRandom(0,19)*this.width;
    this.y = tools.getRandom(0,19)*this.height;
    // this.color = tools.getColor();
    var ele = document.createElement("div");
    ele.style.width = this.width+"px";
    ele.style.height = this.height+"px";
    ele.style.left = this.x+"px";
    ele.style.top = this.y+"px";
    ele.style.backgroundColor = this.color;
    ele.style.position = "absolute";
    map.appendChild(ele);
    this.elements.push(ele);
}
Food.prototype.delect = function(map){
     map.removeChild(this.elements[0]);
     this.elements.splice(0,1);
}
window.Food =Food;
}
)()

// 
// var map = document.getElementById("map");
// var food = new Food();
// food.render(map);
// setTimeout(function(){
// food.delect(map);
// },2000)
// food.render(map);
// food.render(map);