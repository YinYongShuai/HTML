
(function (window) {
	'use strict';

	let filters = {
		all(todos){
			return todos;
		},
		active(todos){
			return todos.filter(function(todo){
				return !todo.completed
			})
		},
		completed(todos){
            return todos.filter(function(todo){
				return todo.completed
			})
		}
	};

	// Your starting point. Enjoy the ride!
	new Vue ({
		el :"#app",
		data:{
			
			todos:[
				{id: 1,title:"实例内容",completed:true},
				{id: 2,title:"实例内容",completed:false},
				{id: 3,title:"实例内容",completed:false}
			],
			newToDo : "",
			editingTodo : null,
			titleBefore : "",
			todoType : "all"
		},
		methods : {
               sos : function(){
				   return this.remaining === 1 ? "item" : "items"
			   },
			   addToDo : function(){
                   var value = this.newToDo;
				   if(!this.newToDo){
					   return;
				   }
				   this.todos.push({id : this.todos.length+1,title : value,completed : false});
				   this.newToDo = "";
			   },
			   removeToDo : function(todo){
				   var index = this.todos.indexOf(todo);
				   this.todos.splice(index,1);
			   },
			   removeCompleted : function(){
				   this.todos = this.todos.filter(function(todo){
					   return !todo.completed;
				   })
			   },
			   editTodo : function(todo){
				   this.editingTodo = todo;
				   this.titleBefore = todo.title;
			   },
			   cancelEdit : function(todo){
				   this.editingTodo=null;

			   },
			   editDone :function(todo){
				   this.editingTodo = null;
				   todo.title = todo.title.trim();
				   if(!todo.title){
					   this.removeTodo(todo);
				   }
			   }
		},
		computed :{
			remaining(){
				return this.todos.filter(function(todo){
					return !todo.completed;
				}).length
			},
			allDone : {
				get : function(){
					return this.remaining===0;
				},
				set :function(value){
					this.todos.forEach(function (todo){
						todo.completed=value;
					})
				}
			},
			filteredTodo(){
				return filters[this.todoType](this.todos)
			}
		},
		directives : {
			"todo-focus"(el,binding){
				if(binding.value){
					el.focus();
				}
			}
		}

	})

})(window);
